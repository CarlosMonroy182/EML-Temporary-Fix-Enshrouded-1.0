use std::{
    path::{Path, PathBuf},
    sync::atomic::{AtomicBool, Ordering},
    time::SystemTime,
};

use serde::Deserialize;

pub const CONFIG_FILE: &str = "m182_native.json";

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct NativeConfig {
    /// Master switch. When false nothing in the game is touched.
    pub enabled: bool,
    /// Players are hostile to each other (all other relations stay vanilla).
    pub pvp: bool,
    /// Also apply the player-vs-player rule to the "friend" checks.
    pub pvp_friend_checks: bool,
}

impl Default for NativeConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            pvp: false,
            pvp_friend_checks: false,
        }
    }
}

pub fn load(path: &Path) -> Result<NativeConfig, String> {
    match std::fs::read_to_string(path) {
        Ok(text) => serde_json::from_str(&text).map_err(|e| e.to_string()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(NativeConfig::default()),
        Err(e) => Err(e.to_string()),
    }
}

pub fn modified(path: &Path) -> Option<SystemTime> {
    std::fs::metadata(path).and_then(|m| m.modified()).ok()
}

/// Settings the hooks read on every call.
pub struct LiveState {
    pub pvp: AtomicBool,
    pub pvp_friend_checks: AtomicBool,
}

pub static LIVE: LiveState = LiveState {
    pvp: AtomicBool::new(false),
    pvp_friend_checks: AtomicBool::new(false),
};

impl LiveState {
    pub fn apply(&self, cfg: &NativeConfig) {
        self.pvp.store(cfg.enabled && cfg.pvp, Ordering::Relaxed);
        self.pvp_friend_checks
            .store(cfg.enabled && cfg.pvp && cfg.pvp_friend_checks, Ordering::Relaxed);
    }

    #[inline]
    pub fn pvp(&self) -> bool {
        self.pvp.load(Ordering::Relaxed)
    }

    #[inline]
    pub fn pvp_friend_checks(&self) -> bool {
        self.pvp_friend_checks.load(Ordering::Relaxed)
    }
}

pub fn config_path(dir: &Path) -> PathBuf {
    dir.join(CONFIG_FILE)
}
